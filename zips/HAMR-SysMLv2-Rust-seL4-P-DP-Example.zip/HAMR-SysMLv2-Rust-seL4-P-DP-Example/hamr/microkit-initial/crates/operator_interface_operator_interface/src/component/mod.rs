// This file will not be overwritten if HAMR codegen is rerun

pub mod operator_interface_operator_interface_app;
// PLACEHOLDER MARKER R2U2 MONITOR MODULE
