// This file will not be overwritten if codegen is rerun

use data::*;
use crate::bridge::thermostat_thermostat_api::*;
use vstd::prelude::*;

verus! {

  pub struct thermostat_thermostat {
    // BEGIN MARKER STATE VARS
    pub lastCmd: Isolette_Data_Model::On_Off,
    // END MARKER STATE VARS
  }

  impl thermostat_thermostat {
    pub fn new() -> Self
    {
      Self {
        // BEGIN MARKER STATE VAR INIT
        lastCmd: Isolette_Data_Model::On_Off::default(),
        // END MARKER STATE VAR INIT
      }
    }

    pub fn initialize<API: thermostat_thermostat_Put_Api> (
      &mut self,
      api: &mut thermostat_thermostat_Application_Api<API>)
      ensures
        // BEGIN MARKER INITIALIZATION ENSURES
        // guarantee initlastCmd
        final(self).lastCmd == Isolette_Data_Model::On_Off::Off,
        // guarantee REQ_THERM_1
        //   The Heat Control command shall be Off initially.
        final(api).heat_control == Isolette_Data_Model::On_Off::Off,
        // END MARKER INITIALIZATION ENSURES
    {
      log_info("initialize entrypoint invoked");
    }

    pub fn timeTriggered<API: thermostat_thermostat_Full_Api> (
      &mut self,
      api: &mut thermostat_thermostat_Application_Api<API>)
      requires
        // BEGIN MARKER TIME TRIGGERED REQUIRES
        // assume ASSM_LDT_LE_UDT
        old(api).desired_temp.lower.degrees <= old(api).desired_temp.upper.degrees,
        // END MARKER TIME TRIGGERED REQUIRES
      ensures
        // BEGIN MARKER TIME TRIGGERED ENSURES
        // guarantee lastCmd
        //   Set lastCmd to value of output Cmd port
        final(self).lastCmd == final(api).heat_control,
        // case REQ_THERM_2
        //   If Current Temperature is less than
        //   the Lower Desired Temperature, the Heat Control shall be set to On.
        (old(api).current_temp.degrees < old(api).desired_temp.lower.degrees) ==>
          (final(api).heat_control == Isolette_Data_Model::On_Off::Onn),
        // case REQ_THERM_3
        //   If the Current Temperature is greater than
        //   the Upper Desired Temperature, the Heat Control shall be set to Off.
        (old(api).current_temp.degrees > old(api).desired_temp.upper.degrees) ==>
          (final(api).heat_control == Isolette_Data_Model::On_Off::Off),
        // case REQ_THERM_4
        //   If the Current Temperature is greater than or equal 
        //   to the Lower Desired Temperature
        //   and less than or equal to the Upper Desired Temperature, the value of
        //   the Heat Control shall not be changed.
        ((old(api).current_temp.degrees >= old(api).desired_temp.lower.degrees) &&
          (old(api).current_temp.degrees <= old(api).desired_temp.upper.degrees)) ==>
          (final(api).heat_control == old(self).lastCmd),
        // END MARKER TIME TRIGGERED ENSURES
    {
      log_info("compute entrypoint invoked");
    }

    pub fn notify(
      &mut self,
      channel: microkit_channel)
    {
      // this method is called when the monitor does not handle the passed in channel
      match channel {
        _ => {
          log_warn_channel(channel)
        }
      }
    }
  }

  #[verifier::external_body]
  pub fn log_info(msg: &str)
  {
    log::info!("{0}", msg);
  }

  #[verifier::external_body]
  pub fn log_warn_channel(channel: u32)
  {
    log::warn!("Unexpected channel: {0}", channel);
  }

  // BEGIN MARKER GUMBO METHODS
  pub open spec fn Temp_Lower_Bound() -> i32
  {
    95i32
  }

  pub open spec fn Temp_Upper_Bound() -> i32
  {
    104i32
  }
  // END MARKER GUMBO METHODS

}
