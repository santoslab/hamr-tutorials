// #Sireum

package ProdConsExample

import org.sireum._

// This file will not be overwritten so is safe to edit

// Any datatype definitions placed in this file will be processed by sergen and SlangCheck
