// #Sireum

package art.scheduling.static

import org.sireum._

@ext object StaticSchedulerIO {
  def getCommand(prompt: String): String = $

  def message(m: String): Unit = $
}
