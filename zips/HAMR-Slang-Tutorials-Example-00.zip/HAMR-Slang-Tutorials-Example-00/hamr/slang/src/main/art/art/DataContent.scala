// #Sireum

package art

import org.sireum._

@sig trait DataContent

@datatype class Empty extends art.DataContent