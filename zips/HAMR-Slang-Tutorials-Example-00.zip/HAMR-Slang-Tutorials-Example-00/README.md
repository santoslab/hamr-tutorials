HAMR Slang Project that is the starting point for the HAMR Slang tutorials including:
  - Importing Existing AADL Project into OSATE
  - Importing Existing Slang Project into SIREUM IVE (IntelliJ)
  - Refactoring AADL Project (which will produce an intermediate state reflected in HAMR-Slang-Tutorials-Example-00-AADL-Refactored)
  - Refactoring Slang Project
 
 Change Log:
  - Updated Sept 2023 to account for new unit testing APIs
